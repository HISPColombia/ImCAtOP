Dhis2Api.directive('d2Secondarymenu', function(){
return{
	restrict: 'E',
	templateUrl: 'directives/menu/menuView.html'
}
})