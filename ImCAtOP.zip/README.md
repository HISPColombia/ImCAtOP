# Apps para importar opciones de categorias
# Desarrollado por Helder Castrillón
# HISP Colombia 2016.

#descripión general.


 # Funcionalidades
 

 
 # recomendaciones especiales.
